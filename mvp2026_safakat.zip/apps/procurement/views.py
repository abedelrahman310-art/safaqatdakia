from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Tender, Bid, TenderQuestion, SupplierRating, DocumentPayment
from apps.core.models import Notification
from .forms import TenderForm, BidForm
from django.db.models import Q, Avg
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
import uuid

def tender_list(request):
    tenders = Tender.objects.filter(status='published')
    
    query = request.GET.get('q')
    wilaya = request.GET.get('wilaya')
    sector = request.GET.get('sector')
    
    if query:
        tenders = tenders.filter(
            Q(title__icontains=query) | Q(description__icontains=query)
        )
    
    if wilaya:
        tenders = tenders.filter(wilaya=wilaya)
        
    if sector:
        tenders = tenders.filter(sector=sector)
        
    paid_tender_ids = []
    if request.user.is_authenticated and request.user.role == 'supplier':
        paid_tender_ids = list(DocumentPayment.objects.filter(supplier=request.user).values_list('tender_id', flat=True))
        
    context = {
        'tenders': tenders,
        'query': query,
        'wilaya': wilaya,
        'sector': sector,
        'paid_tender_ids': paid_tender_ids
    }
    return render(request, 'procurement/tender_list.html', context)

def authority_tender_list(request):
    tenders = Tender.objects.all()
    return render(request, 'procurement/authority_tender_list.html', {'tenders': tenders})

def tender_create(request):
    if request.method == 'POST':
        form = TenderForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('procurement:authority_tender_list')
    else:
        form = TenderForm()
    
    return render(request, 'procurement/tender_form.html', {'form': form})

def bid_create(request, tender_id):
    tender = get_object_or_404(Tender, id=tender_id)
    if request.method == 'POST':
        form = BidForm(request.POST, request.FILES)
        if form.is_valid():
            bid = form.save(commit=False)
            bid.tender = tender
            bid.supplier_name = request.user.full_name or request.user.email
            bid.nif_number = getattr(request.user, 'national_id', '')
            bid.nis_number = getattr(request.user, 'commercial_register', '')
            bid.save()
            
            Notification.objects.create(
                user=tender.authority,
                message=f"تم تقديم عرض جديد للصفقة: {tender.title}",
                link=f"/procurement/tenders/{tender.id}/bids/"
            )
            
            # Send Email
            try:
                send_mail(
                    subject=f"تأكيد استلام العرض: {tender.title}",
                    message=f"أهلاً بك،\n\nنؤكد لك استلام عرضك الخاص بالصفقة: {tender.title} بنجاح.\nسيتم تقييم العروض بعد انقضاء الآجال.\n\nفريق صفقات ذكية",
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[request.user.email] if request.user.email else [],
                    fail_silently=True,
                )
            except Exception:
                pass
            
            return redirect('procurement:tender_list')
    else:
        form = BidForm()
    
    return render(request, 'procurement/bid_form.html', {'form': form, 'tender': tender})

def authority_tender_bids(request, tender_id):
    tender = get_object_or_404(Tender, id=tender_id)
    bids = list(tender.bids.all())
    
    if bids:
        min_financial = min((b.financial_offer for b in bids if b.financial_offer), default=0)
        min_delivery = min((b.delivery_time_days for b in bids if b.delivery_time_days), default=0)
        max_warranty = max((b.warranty_months for b in bids if b.warranty_months), default=0)
        max_projects = max((b.similar_projects_count for b in bids if b.similar_projects_count), default=0)
        
        for bid in bids:
            score = 0
            if bid.financial_offer and min_financial > 0:
                score += (float(min_financial) / float(bid.financial_offer)) * 40
            if bid.delivery_time_days and min_delivery > 0:
                score += (float(min_delivery) / float(bid.delivery_time_days)) * 20
            if bid.similar_projects_count and max_projects > 0:
                score += (float(bid.similar_projects_count) / float(max_projects)) * 20
            if bid.warranty_months and max_warranty > 0:
                score += (float(bid.warranty_months) / float(max_warranty)) * 10
            
            avg_rating = SupplierRating.objects.filter(supplier_name=bid.supplier_name).aggregate(Avg('rating'))['rating__avg']
            if avg_rating:
                score += (float(avg_rating) / 5.0) * 10
                
            bid.smart_score = round(score, 1)
            bid.avg_rating = round(avg_rating, 1) if avg_rating else "جديد"
            
        bids.sort(key=lambda x: getattr(x, 'smart_score', 0), reverse=True)
        if len(bids) > 0 and hasattr(bids[0], 'smart_score') and bids[0].smart_score > 0:
            bids[0].is_best = True

    return render(request, 'procurement/authority_bids_list.html', {'tender': tender, 'bids': bids})

def bid_update_status(request, bid_id, status):
    bid = get_object_or_404(Bid, id=bid_id)
    if status in ['accepted', 'rejected', 'pending']:
        bid.status = status
        bid.save()
        
        from django.contrib.auth import get_user_model
        User = get_user_model()
        supplier_user = User.objects.filter(full_name=bid.supplier_name).first()
        
        if supplier_user:
            msg = "تم قبول عرضك!" if status == 'accepted' else "تم تحديث حالة عرضك إلى: " + status
            Notification.objects.create(
                user=supplier_user,
                title="إشعار بخصوص عرضك",
                message=f"{msg} - الصفقة: {bid.tender.title}",
                link="/dashboard/supplier/"
            )
            # Send Email
            try:
                send_mail(
                    subject=f"إشعار بخصوص عرضك للصفقة: {bid.tender.title}",
                    message=f"أهلاً بك،\n\nنعلمك أنه {msg}\nيمكنك الدخول للمنصة لمزيد من التفاصيل.\n\nفريق صفقات ذكية",
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[supplier_user.email] if supplier_user.email else [],
                    fail_silently=True,
                )
            except Exception:
                pass
                
    return redirect('procurement:authority_tender_bids', tender_id=bid.tender.id)

@login_required
def rate_supplier(request, bid_id):
    bid = get_object_or_404(Bid, id=bid_id)
    if request.method == 'POST':
        rating = request.POST.get('rating')
        review = request.POST.get('review_text', '')
        if rating and rating.isdigit() and 1 <= int(rating) <= 5:
            SupplierRating.objects.create(
                supplier_name=bid.supplier_name,
                authority=request.user,
                tender=bid.tender,
                rating=int(rating),
                review_text=review
            )
    return redirect('procurement:authority_tender_bids', tender_id=bid.tender.id)

def generate_report_view(request, tender_id):
    tender = get_object_or_404(Tender, id=tender_id)
    bids = list(tender.bids.all())
    
    # Calculate scores again just for the report, or better, we could save them in the DB.
    # For now we calculate them on the fly as we did before.
    if bids:
        min_financial = min((b.financial_offer for b in bids if b.financial_offer), default=0)
        min_delivery = min((b.delivery_time_days for b in bids if b.delivery_time_days), default=0)
        max_warranty = max((b.warranty_months for b in bids if b.warranty_months), default=0)
        max_projects = max((b.similar_projects_count for b in bids if b.similar_projects_count), default=0)
        
        for bid in bids:
            score = 0
            if bid.financial_offer and min_financial > 0:
                score += (float(min_financial) / float(bid.financial_offer)) * 50
            if bid.delivery_time_days and min_delivery > 0:
                score += (float(min_delivery) / float(bid.delivery_time_days)) * 20
            if bid.similar_projects_count and max_projects > 0:
                score += (float(bid.similar_projects_count) / float(max_projects)) * 20
            if bid.warranty_months and max_warranty > 0:
                score += (float(bid.warranty_months) / float(max_warranty)) * 10
            bid.smart_score = round(score, 1)
            
        bids.sort(key=lambda x: getattr(x, 'smart_score', 0), reverse=True)
        if len(bids) > 0 and hasattr(bids[0], 'smart_score') and bids[0].smart_score > 0:
            bids[0].is_best = True

    return render(request, 'procurement/evaluation_report.html', {'tender': tender, 'bids': bids})
from .models import TenderQuestion, SupplierRating
from django.utils import timezone

@login_required
def tender_detail(request, tender_id):
    tender = get_object_or_404(Tender, id=tender_id)
    questions = tender.questions.all().order_by('-created_at')
    
    has_paid = False
    if request.user.is_authenticated and request.user.role == 'supplier':
        from .models import DocumentPayment
        has_paid = DocumentPayment.objects.filter(tender=tender, supplier=request.user).exists()
    
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'ask_question' and request.user.role == 'supplier':
            question_text = request.POST.get('question_text')
            if question_text:
                TenderQuestion.objects.create(
                    tender=tender,
                    supplier=request.user,
                    question_text=question_text
                )
                return redirect('procurement:tender_detail', tender_id=tender.id)
                
        elif action == 'answer_question' and request.user.role == 'authority':
            question_id = request.POST.get('question_id')
            answer_text = request.POST.get('answer_text')
            if question_id and answer_text:
                q = get_object_or_404(TenderQuestion, id=question_id)
                q.answer_text = answer_text
                q.answered_at = timezone.now()
                q.save()
                return redirect('procurement:tender_detail', tender_id=tender.id)
                
    return render(request, 'procurement/tender_detail.html', {'tender': tender, 'questions': questions, 'has_paid': has_paid})

import uuid
from .models import DocumentPayment

@login_required
def payment_checkout(request, tender_id):
    tender = get_object_or_404(Tender, id=tender_id)
    if tender.document_fee <= 0:
        return redirect('procurement:tender_detail', tender_id=tender.id)
        
    return render(request, 'procurement/payment_checkout.html', {'tender': tender})

@login_required
def process_payment(request, tender_id):
    tender = get_object_or_404(Tender, id=tender_id)
    if request.method == 'POST':
        # Simulate payment gateway processing
        card_number = request.POST.get('card_number')
        if card_number:
            # Create payment record
            DocumentPayment.objects.create(
                tender=tender,
                supplier=request.user,
                amount=tender.document_fee,
                transaction_id=f"TXN-{uuid.uuid4().hex[:10].upper()}"
            )
            from django.contrib import messages
            messages.success(request, "تم الدفع بنجاح! يمكنك الآن سحب دفتر الشروط.")
    return redirect('procurement:tender_detail', tender_id=tender.id)

@login_required
def my_bids(request):
    if request.user.role != 'supplier':
        return redirect('dashboard:authority')
        
    bids = Bid.objects.filter(supplier_name=request.user.full_name or request.user.email).order_by('-submitted_at')
    return render(request, 'procurement/my_bids.html', {'bids': bids})

@login_required
def tender_evaluation_list(request):
    if request.user.role != 'authority':
        return redirect('dashboard:supplier')
        
    from django.utils import timezone
    # Tenders belonging to this authority that have passed the deadline
    tenders_to_evaluate = Tender.objects.filter(
        created_by=request.user,
        deadline__lt=timezone.now().date()
    ).exclude(status='draft').order_by('-deadline')
    
    return render(request, 'procurement/tender_evaluation_list.html', {'tenders': tenders_to_evaluate})

from django.http import HttpResponse
from django.template.loader import get_template
import xhtml2pdf.pisa as pisa
import io

@login_required
def download_tender_pdf(request, tender_id):
    tender = get_object_or_404(Tender, id=tender_id)
    
    # Check if user has permission
    if request.user.role == 'supplier':
        paid = DocumentFee.objects.filter(tender=tender, supplier=request.user, is_paid=True).exists()
        if not paid:
            from django.contrib import messages
            messages.error(request, "يجب دفع رسوم سحب الدفتر أولاً لتتمكن من تحميل نسخة PDF.")
            return redirect('procurement:tender_detail', tender_id=tender.id)

    template_path = 'procurement/tender_pdf_template.html'
    context = {'tender': tender}
    
    # Render template
    template = get_template(template_path)
    html = template.render(context)
    
    # Create PDF
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="Tender_{tender.reference_number}.pdf"'
    
    # We pass the rendered HTML to xhtml2pdf
    pisa_status = pisa.CreatePDF(html, dest=response, encoding='utf-8')
    
    if pisa_status.err:
        return HttpResponse('حدث خطأ أثناء توليد ملف الـ PDF.', status=500)
    return response
