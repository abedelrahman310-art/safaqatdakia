from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth import get_user_model

User = get_user_model()

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('username')
        password = request.POST.get('password')
        role = request.POST.get('role')
        
        try:
            user_obj = User.objects.get(email=email)
            user = authenticate(request, username=user_obj.username, password=password)
        except User.DoesNotExist:
            user = None
            
        if user is not None:
            login(request, user)
            if user.role == 'authority':
                return redirect('dashboard:authority')
            else:
                return redirect('dashboard:supplier')
        else:
            messages.error(request, 'البريد الإلكتروني أو كلمة المرور غير صحيحة.')
            
    return render(request, 'accounts/login.html')

def register_view(request):
    if request.method == 'POST':
        role = request.POST.get('role')
        full_name = request.POST.get('full_name')
        email = request.POST.get('email')
        password = request.POST.get('password1')
        password_confirm = request.POST.get('password2')
        wilaya = request.POST.get('wilaya')
        
        if password != password_confirm:
            messages.error(request, 'كلمات المرور غير متطابقة')
            return render(request, 'accounts/register.html')
            
        if User.objects.filter(email=email).exists():
            messages.error(request, 'هذا البريد الإلكتروني مسجل مسبقاً')
            return render(request, 'accounts/register.html')
            
        # Create user
        user = User.objects.create_user(
            username=email, # Use email as username since we don't ask for a username
            email=email,
            password=password,
            role=role,
            full_name=full_name,
            wilaya=wilaya
        )
        
        if role == 'supplier':
            user.national_id = request.POST.get('national_id')
            user.commercial_register = request.POST.get('commercial_register')
            user.company_type = request.POST.get('company_type')
        elif role == 'authority':
            user.institution_name = request.POST.get('institution_name')
            user.sector = request.POST.get('sector')
            
        user.save()
        
        login(request, user)
        if role == 'authority':
            return redirect('dashboard:authority')
        else:
            return redirect('dashboard:supplier')

    return render(request, 'accounts/register.html')

def logout_view(request):
    logout(request)
    return redirect('core:index')

def profile_view(request):
    if request.method == 'POST':
        messages.success(request, "تم تحديث الملف الشخصي بنجاح!")
    return render(request, 'accounts/profile.html')

from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.decorators import login_required

@login_required
def settings_view(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important to keep the user logged in
            messages.success(request, 'تم تغيير كلمة المرور بنجاح!')
            return redirect('accounts:settings')
        else:
            messages.error(request, 'يرجى تصحيح الأخطاء أدناه.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'accounts/settings.html', {'form': form})
