from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    ROLE_CHOICES = (
        ('authority', 'مصلحة متعاقدة'),
        ('supplier', 'متعامل اقتصادي'),
    )
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    full_name = models.CharField(max_length=255, blank=True, null=True, verbose_name="الاسم الكامل")
    wilaya = models.CharField(max_length=100, blank=True, null=True, verbose_name="الولاية")
    
    # Supplier fields
    national_id = models.CharField(max_length=100, blank=True, null=True, verbose_name="بطاقة التعريف الوطني")
    commercial_register = models.CharField(max_length=100, blank=True, null=True, verbose_name="رقم السجل التجاري")
    company_type = models.CharField(max_length=50, blank=True, null=True, verbose_name="نوع الشركة")
    commercial_register_doc = models.FileField(upload_to='suppliers/rc/', null=True, blank=True, verbose_name="نسخة السجل التجاري (PDF)")
    tax_card_doc = models.FileField(upload_to='suppliers/tax/', null=True, blank=True, verbose_name="نسخة البطاقة الجبائية (PDF)")
    
    # Authority fields
    institution_name = models.CharField(max_length=255, blank=True, null=True, verbose_name="التسمية الرسمية للمصلحة")
    sector = models.CharField(max_length=255, blank=True, null=True, verbose_name="القطاع الوصي")

    @property
    def display_name(self):
        if self.role == 'authority' and self.institution_name:
            return self.institution_name
        return self.full_name or self.username

    def __str__(self):
        return self.email or self.username
